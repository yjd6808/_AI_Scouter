# Scouter 이어하기 (다른 PC용)

## 1. 준비
- Node 20.16.0, npm 10.8.1 (Volta면 `volta pin node@20.16.0 npm@10.8.1`)
- `Scouter/`에서 `npm install` (Electron 바이너리 포함, 시간 걸림)
- `scouter-fable5/`는 설계 문서, 수정 금지. 구현 순서의 유일한 기준.

## 2. 상태 확인 (반드시 녹색)
```
npm run lint
npm run typecheck
npm run build
npm run test:unit     # 154개
npm run test:e2e       # 5개
```

## 3. 현재 위치
- 완료: P0 ~ P8 (문서 02~17, 19, 20). `.admin/plans/`에 Phase별 기록.
- 다음: **P9 운영 (문서 18 CommandPalette + 21 Operations-Packaging)**
- 그 다음: P10 컨트롤 2차 (문서 11, 12 나머지)
- 사용자 확인 대기: 실제 p4 depot 1~40 동작 (문서 19.9)

## 4. 핵심 결정 (23-Decisions.md에 없음, 실측 결과)
- D-20: `Source/Scouter.App/package.json` type:module. tsx 이중 모듈 방지.
- D-21: 내장 플러그인은 번들 금지, 직접 import. 번들하면 싱글톤 복제됨.
- D-22: MCP 통합 테스트는 node:http + 자식 프로세스 SDK. happy-dom fetch 불가.
- D-23: `ctx.Shell.Exec`에 Signal/MaxOutputBytes.
- D-24: Windows `Process.Run`은 shell:true (PATHEXT).
- 식 참조 문법: `{{@x} + `s`}`, 문자열은 백틱만, Data 타입은 Int/Bool, GridView 열은 코드 선언.

## 5. 작업 규칙
- 한국어 답변. 탭 들여쓰기 + Allman 브레이스.
- 한글 주석은 Write 도구로만 작성.
- 파일 1개 = 클래스 1개 (파일명과 클래스명 일치).
- 02-CodingConvention.md와 기존 코드 패턴을 따른다.
- 확인 후 실행: lint → typecheck → build → test:unit → test:e2e.
